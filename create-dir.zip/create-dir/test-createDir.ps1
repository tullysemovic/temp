# test-createDir.ps1 - side-by-side check of createDir.ps1 against createDir.py on throwaway folders.
# Run on the server BEFORE removing Python, from any folder:
#   powershell -NoProfile -ExecutionPolicy Bypass -File test-createDir.ps1
# If the Python original has been renamed (e.g. createDir-backup.py), pass it with -PyScript.
# Only touches folders it creates under %TEMP%. Nothing under E:\ is read or changed.

param(
    [string]$PythonExe = 'C:\Program Files\Python312\python.exe',
    [string]$PyScript  = 'e:\command-center-3.2.0\var\tools\createDir.py',
    [string]$PsScript  = 'e:\command-center-3.2.0\var\tools\createDir.ps1'
)
$ErrorActionPreference = 'Continue'
$ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

# Run a program with exact arguments, capturing stdout, stderr and the exit code separately.
function Invoke-Exe([string]$exe, [string[]]$argList) {
    $quoted = @($argList | ForEach-Object { '"' + $_ + '"' })
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $exe
    $psi.Arguments = ($quoted -join ' ')
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.WorkingDirectory = $env:TEMP
    $p = [System.Diagnostics.Process]::Start($psi)
    $errTask = $p.StandardError.ReadToEndAsync()
    $out = $p.StandardOutput.ReadToEnd()
    $p.WaitForExit()
    return [pscustomobject]@{ Out = $out.TrimEnd(); Err = $errTask.Result.TrimEnd(); Code = $p.ExitCode }
}

# Each case runs Python, records the result, resets the sandbox, then runs PowerShell on the
# SAME path, so the printed messages can be compared exactly.
function Run-Case([string]$label, [scriptblock]$setup, [string[]]$scriptArgs, [string]$checkPath) {
    $base = Join-Path $env:TEMP ('createDir-test-' + [guid]::NewGuid().ToString('N'))
    $results = @{}
    foreach ($kind in 'py', 'ps') {
        New-Item -ItemType Directory -Path $base -Force | Out-Null
        & $setup $base
        $a = @($scriptArgs | ForEach-Object { $_.Replace('{BASE}', $base) })
        if ($kind -eq 'py') { $r = Invoke-Exe $PythonExe (@($PyScript) + $a) }
        else { $r = Invoke-Exe $ps (@('-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', $PsScript) + $a) }
        $exists = $false
        if ($checkPath) { $exists = [System.IO.Directory]::Exists($checkPath.Replace('{BASE}', $base)) }
        $r | Add-Member -NotePropertyName DirExists -NotePropertyValue $exists
        $results[$kind] = $r
        Get-ChildItem $base -Recurse -Force -File -ErrorAction SilentlyContinue | ForEach-Object { $_.IsReadOnly = $false }
        Remove-Item $base -Recurse -Force -ErrorAction SilentlyContinue
    }
    $py = $results['py']; $pw = $results['ps']
    # stderr wording differs on errors (Python prints a traceback), so only compare whether there was any
    $ok = ($py.Out -eq $pw.Out) -and ($py.Code -eq $pw.Code) -and ($py.DirExists -eq $pw.DirExists) -and
          ([bool]$py.Err -eq [bool]$pw.Err)
    if ($ok) { $verdict = 'PASS' } else { $verdict = 'FAIL' }
    Write-Host ("[{0}] {1}" -f $verdict, $label)
    Write-Host ("   exit: py={0} ps={1}   folder exists after: py={2} ps={3}" -f $py.Code, $pw.Code, $py.DirExists, $pw.DirExists)
    Write-Host ('   stdout py: ' + ($py.Out -replace "`r?`n", ' | '))
    Write-Host ('   stdout ps: ' + ($pw.Out -replace "`r?`n", ' | '))
    if ($py.Err) { Write-Host ('   stderr py (last line): ' + ($py.Err -split "`r?`n")[-1]) }
    if ($pw.Err) { Write-Host ('   stderr ps (last line): ' + ($pw.Err -split "`r?`n")[-1]) }
}

$none = { param($b) }

Run-Case 'no argument (usage, exit 1)'           $none @()                          $null
Run-Case 'new folder with missing parents'       $none @('{BASE}\a\b\c')             '{BASE}\a\b\c'
Run-Case 'path with spaces and [brackets]'       $none @('{BASE}\job [1]\out dir')   '{BASE}\job [1]\out dir'
Run-Case 'folder already exists'                 { param($b) New-Item -ItemType Directory -Path "$b\exists" | Out-Null } @('{BASE}\exists') '{BASE}\exists'
Run-Case 'a FILE already exists at the path'     { param($b) Set-Content -Path "$b\afile" -Value 'x' } @('{BASE}\afile') '{BASE}\afile'
Run-Case 'parent is a file (create fails)'       { param($b) Set-Content -Path "$b\afile" -Value 'x' } @('{BASE}\afile\sub') '{BASE}\afile\sub'
Run-Case 'invalid characters (create fails)'     $none @('{BASE}\bad<name>')         $null
Run-Case 'extra arguments are ignored'           $none @('{BASE}\x', 'extra', 'more') '{BASE}\x'
