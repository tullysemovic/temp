SET DIRPATH=%1

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File e:\command-center-3.2.0\var\tools\createDir.ps1 %DIRPATH%

exit %ERRORLEVEL%
