# ===================================================================================================
# createDir.ps1
# ===================================================================================================
# Drop-in replacement for createDir.py.
# Built-in Windows PowerShell 5.1 only: no modules, no installs. Tested target: Windows Server 2019.
#
# Description:
#     Creates the given directory (including any missing parent folders) if it does not exist.
#     If anything (a folder OR a file) already exists at that path, it only reports it.
#
# Usage:
#     powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File createDir.ps1 <directory full path>
#
# Output and exit codes (same as Python):
#     "Directory doesnt exit, creating directory:<path>"   then creates it        exit 0
#     "Directory exits."                                    path already exists    exit 0
#     "usage: createDir.py <directory full path>"           no argument            exit 1
#                                                           (printed on stdout, and again on stderr)
#     error text on stderr                                  folder could not be    exit 1
#                                                           created (bad path, no access, ...)
#     The misspellings ("doesnt exit", "exits") are kept on purpose, in case anything matches on them.
# ===================================================================================================
# Amendment History
# Date        Version  Description
# ----------- -------- ------------------------------------------------------------------------------
# 2026/11/27  2.0      PowerShell port of createDir.py to remove the Python dependency
# ===================================================================================================

$ErrorActionPreference = 'Stop'

function Fail([string]$msg) {
    [Console]::Error.WriteLine($msg)
    exit 1
}

# ----------------------------------------------------------------------
# Arguments (positional, via $args, to mirror sys.argv). Extra arguments are ignored, as in Python.
if ($args.Count -lt 1) {
    # print(...) to stdout, then sys.exit("...") prints the same text to stderr and exits 1
    Write-Output 'usage: createDir.py <directory full path>'
    Fail 'usage: createDir.py <directory full path>'
}

$directory = [string]$args[0]

# ----------------------------------------------------------------------
# os.path.exists(): true for an existing folder OR file. .NET is used instead of Test-Path so
# that [ ] and * in a path are taken literally and an empty path doesn't throw.
$exists = $false
try {
    $exists = [System.IO.Directory]::Exists($directory) -or [System.IO.File]::Exists($directory)
} catch {
    $exists = $false
}

if (-not $exists) {
    Write-Output ('Directory doesnt exit, creating directory:' + $directory)
    try {
        # os.makedirs(): creates missing parents too. Relative paths resolve against the current
        # directory the .bat was started in, as with Python.
        [System.IO.Directory]::CreateDirectory($directory) | Out-Null
    }
    catch {
        $e = $_.Exception
        while ($e.InnerException) { $e = $e.InnerException }
        Fail ('OSError: ' + $e.Message)
    }
}
else {
    Write-Output 'Directory exits.'
}
exit 0
