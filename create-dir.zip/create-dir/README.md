# Replacing createDir.py with PowerShell

The Command Center `createDir` tool on Windows Server 2019, moved off Python onto the built-in Windows PowerShell 5.1, the same way as `cleanup` (see `../cc-cleanup/`). It needs no modules and nothing installed.

## Files

| File | What it is |
|---|---|
| `createDir.ps1` | Replacement for `createDir.py`. Copy it to `e:\command-center-3.2.0\var\tools\` |
| `createDir.bat` | Updated batch file that calls PowerShell instead of Python |
| `test-createDir.ps1` | Runs the Python and PowerShell versions side by side on throwaway folders in %TEMP% and compares the results. Run it **before** you uninstall Python |

## The new .bat

```bat
SET DIRPATH=%1

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File e:\command-center-3.2.0\var\tools\createDir.ps1 %DIRPATH%

exit %ERRORLEVEL%
```

* Same switches as `cleanup.bat`: `-ExecutionPolicy Bypass` applies to this one process only (a Group Policy execution policy still wins over it), `-NoProfile` skips profile scripts, `-NonInteractive` fails instead of waiting for input.
* `-File` passes the script's exit code through, so `exit %ERRORLEVEL%` still works.

## What createDir.py actually does

1. With no argument it prints `usage: createDir.py <directory full path>` on stdout, then `sys.exit("...")` prints the same line again on **stderr** and exits with **code 1**.
2. `os.path.exists(path)`: if **anything** is at that path, a folder **or a file**, it prints `Directory exits.` and exits 0 without creating anything.
3. Otherwise it prints `Directory doesnt exit, creating directory:<path>` (no space after the colon) and runs `os.makedirs`, which also creates any missing parent folders. Exit 0.
4. If the folder can't be created (bad characters, no access, a parent is a file, missing drive), Python prints a traceback on stderr and exits **1**. The "creating directory" line has already been printed by then.
5. Arguments after the first are ignored.

## Quirks, and what the PowerShell version does with each

| Quirk in createDir.py | Kept? | Notes |
|---|---|---|
| Misspelt messages `doesnt exit` and `exits` | Kept word for word | In case CC or anything reading its logs matches on them |
| No argument exits **1** (unlike cleanup.py, which exits 0) and the usage line appears on stdout and stderr | Kept | |
| A **file** at the path counts as "exists", so it reports `Directory exits.` and exit 0, and no folder is made | Kept | Same as `os.path.exists` |
| Missing parent folders are created | Kept | `[IO.Directory]::CreateDirectory` does the same as `os.makedirs` |
| Relative paths resolve against the folder the .bat was started in | Kept | |
| Wildcard characters `[ ] *` in the path | Taken literally | .NET calls are used instead of `Test-Path`/`New-Item`, which would treat `[ ]` as wildcards |
| Create failure: traceback on stderr, exit 1 | Exit 1 kept, wording differs | PowerShell prints `OSError: <Windows message>` on stderr instead of a Python traceback. Only the log text differs |
| An empty argument (`createDir.bat ""`) prints the "creating" line then fails with exit 1 | Kept | |
| `SET PATH=%1` in the old .bat **overwrites the Windows PATH** for that cmd session | **Changed in the .bat only** | Renamed to `DIRPATH`, as `JOBPATH` was in cleanup.bat. Nothing reads it afterwards. PowerShell is called by its full path, so even the old `PATH` line would still work |
| With no argument, the old .bat's `SET PATH=` empties the variable and Python gets no argument | Kept | `%DIRPATH%` expands to nothing too, so the script prints usage and exits 1 |
| A path with spaces must be quoted by the caller, and a quoted path ending in `\` (`"e:\new dir\"`) gets a stray `"` | Kept | The .bat passes `%1` on unchanged, as before |

## Rollout

1. Copy `createDir.ps1` and `test-createDir.ps1` into `e:\command-center-3.2.0\var\tools\`.
2. While Python is still installed, run
   `powershell -NoProfile -ExecutionPolicy Bypass -File e:\command-center-3.2.0\var\tools\test-createDir.ps1`
   If you've already renamed the original to `createDir-backup.py`, add
   `-PyScript e:\command-center-3.2.0\var\tools\createDir-backup.py`.
   You should get eight `PASS` lines. It only touches folders it creates in %TEMP%.
3. Back up the old `createDir.bat`, replace it with the new one, and let CC run it once.
4. Uninstall Python (once cleanup has been switched over too).
