# Replacing cleanup.py with PowerShell

Command Center job-folder cleanup on Windows Server 2019, moved off Python onto the built-in Windows PowerShell 5.1. It needs no modules and nothing installed.

## Files

| File | What it is |
|---|---|
| `cleanup.ps1` | Replacement for `cleanup.py`. Copy it to `e:\command-center-3.2.0\var\tools\cleanup\` |
| `cleanup.bat` | Updated batch file that calls PowerShell instead of Python |
| `test-cleanup.ps1` | Runs the Python and PowerShell versions side by side on throwaway folders in %TEMP% and compares the results. Run it **before** you uninstall Python |
| `examples/` | The exact bytes the Python script writes on Windows, for the "jobs found" case and the "nothing to clean" case |

## The new .bat

```bat
SET DAYS=%1
SET JOBPATH=%2

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File e:\command-center-3.2.0\var\tools\cleanup\cleanup.ps1 %DAYS% %JOBPATH%

exit %ERRORLEVEL%
```

* `-ExecutionPolicy Bypass` applies to this one process only, so the server's policy is left alone. If a **Group Policy** sets the execution policy (MachinePolicy or UserPolicy scope), it overrides `-ExecutionPolicy Bypass`. You can check with `Get-ExecutionPolicy -List`.
* `-NoProfile` stops PowerShell from loading profile scripts. `-NonInteractive` means the script fails instead of waiting for input.
* `-File` passes the script's exit code through, so `exit %ERRORLEVEL%` still works.

## What cleanup.py actually does

1. With fewer than 2 arguments it prints `usage: cleanup.py <days> <path> <dryrun>` and exits with **code 0**, writing no XML.
2. `days = int(arg1)`. A non-number crashes the script with a traceback and exit code 1, and no XML is written.
3. The cutoff is `now - days*86400` seconds. A folder qualifies when its **modified time is less than or equal to** the cutoff, so a folder exactly at the cutoff counts as old.
4. It lists the jobs folder (`os.listdir`) and keeps **directories only**, hidden ones included. Plain files are ignored. Junctions and symlinks are followed when reading the modified time.
5. It deletes each old folder with `shutil.rmtree`, printing `Deleting: <path>` first. A delete error is printed as `OS error: ...` and the script carries on. It does **not** stop and the exit code stays 0.
6. It writes `JOB_CLEANUP.xml` into the **current working directory**, not the jobs folder. Every job it selected is listed, **including ones whose delete failed**. If nothing was old enough, it prints `Nothing to clean up.` and writes an `EMPTY` action instead.
7. It prints `JOB_CLEANUP.xml has been created.` and exits 0. A missing jobs path or an XML file that can't be written gives a traceback and exit code 1.

## Quirks, and what the PowerShell version does with each

| Quirk in cleanup.py | Kept? | Notes |
|---|---|---|
| `mtime <= cutoff`, so a folder at exactly the cutoff is old | Kept | Compared in UTC, the same as Python's epoch seconds, so daylight saving changes can't shift it |
| XML formatting: `<?xml version='1.0'?>` in single quotes, tab indents, a stray line holding a single space after `<list>` (the space ends up before the first `<value>`), no newline at end of file | Kept byte for byte | Command Center parses this today, so it is reproduced exactly. See `examples/` |
| `xmlns` namespace only on the JOB_CLEANUP variant, not on EMPTY | Kept | |
| Line endings: Python text mode on Windows turns every `\n` into **CRLF** | Kept | The script writes `\r\n` explicitly |
| Encoding: ANSI code page (cp1252), **no BOM** | Kept | Written with `[IO.File]::WriteAllText(..., [Text.Encoding]::Default)`. PowerShell's `Out-File`, `Set-Content` and `>` are deliberately avoided, because in 5.1 they write UTF-16 or add a BOM |
| XML is written to the current working directory | Kept | Command Center presumably picks the file up from there |
| Jobs are listed in the XML even when their delete failed | Kept | This means CC can drop a job from its database while its folder is still on disk. Changing it would change what CC sees, so it is left as it was |
| Delete errors are printed and not fatal, exit code 0 | Kept | |
| Usage message exits 0 and writes no XML | Kept | The text still says `cleanup.py` |
| **Dry-run bug**: `dryrun = bool(sys.argv[2])` tests the *path* argument, which is never empty, so **any** third argument means dry run, even `false` or `0` | Kept (the safe direction) | Your .bat only passes two arguments, so real runs are not affected. Fixing it so `false` meant "delete" would make a run destructive that used to be harmless |
| `dryrun` is a global that only exists when run as a script | Not relevant | It's a plain script variable in PowerShell |
| Negative days put the cutoff in the future, so **every** job folder gets deleted | Kept | This is how the script has always behaved. Be careful with the argument |
| `SET PATH=%2` in the old .bat **overwrites the Windows PATH** for that cmd session | **Changed in the .bat only** | The variable is renamed to `JOBPATH`. Nothing reads it afterwards, so the cleanup itself behaves the same. To keep the old line exactly, change both `JOBPATH`s back to `PATH`. That still works because PowerShell is called by its full path |
| A quoted path ending in `\` (`"e:\jobs\"`) arrives with a trailing `"` and the run fails | Kept | The .bat passes the path unquoted, as before |
| A job folder that is itself a junction or symlink | Kept (refuses) | Python 3.12's `rmtree` refuses links and prints an error. The PS version does the same instead of risking deleting the link target's contents. Links *inside* a job folder are removed, not followed, as with rmtree |
| Read-only files inside a job make the delete fail partway | Kept | Both versions leave a partly deleted folder and print an error |
| A job name with characters the ANSI code page can't hold makes Python crash **after** deleting the folders, leaving an empty `JOB_CLEANUP.xml` and exit code 1. A name containing `&` is written raw, which makes the XML invalid | Kept | Same as Python: folders deleted, empty XML, exit 1. `&` is written as-is. Nothing is ever replaced with `?` |
| Error message wording (`OS error: [WinError 5] ...`) | As close as possible | It still starts `OS error: `, but the rest is Windows' own message. This only affects the console and log text |

## Rollout

1. Copy `cleanup.ps1` and `test-cleanup.ps1` into `e:\command-center-3.2.0\var\tools\cleanup\`.
2. While Python is still installed, run
   `powershell -NoProfile -ExecutionPolicy Bypass -File e:\command-center-3.2.0\var\tools\cleanup\test-cleanup.ps1`
   You should get three `PASS` lines (delete, dry run, nothing to clean). It only touches folders it creates in %TEMP%.
3. Optional: do a dry run against the real jobs folder from a scratch directory. A third argument means nothing is deleted:
   `cd %TEMP% & powershell -NoProfile -ExecutionPolicy Bypass -File e:\command-center-3.2.0\var\tools\cleanup\cleanup.ps1 365 e:\CC\var\jobs\ dryrun`
   This writes `JOB_CLEANUP.xml` into %TEMP%, not where CC reads it from.
4. Back up the old `cleanup.bat`, replace it with the new one, and let CC run it once.
5. Uninstall Python.
