# ===================================================================================================
# cleanup.ps1
# ===================================================================================================
# Drop-in replacement for cleanup.py v1.1 (Tomas Bystrican, 2020).
# Built-in Windows PowerShell 5.1 only: no modules, no installs. Tested target: Windows Server 2019.
#
# Description:
#     Scans the Command Center jobs directory and deletes any job folders whose last-modified
#     time is older than or equal to <days> days ago, then writes JOB_CLEANUP.xml into the
#     CURRENT WORKING DIRECTORY so Command Center can delete those jobs from its database.
#     If nothing qualifies, an EMPTY action XML is written instead.
#
# Usage:
#     powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File cleanup.ps1 <days> <path> [dryrun]
#
#     Any third argument (whatever its value, even "false") turns on dry run, exactly as the
#     Python script did: folders are reported and listed in the XML but nothing is deleted.
#
# Exit codes (same as Python):
#     0  success, including when some folders could not be deleted (errors are printed, not fatal)
#     0  fewer than 2 arguments (usage message printed, no XML written)
#     1  fatal error: <days> not a whole number, jobs path missing/unreadable, XML not writable,
#        or a job name that can't be encoded in the ANSI code page (after deletions, empty XML left)
# ===================================================================================================
# Amendment History
# Date        Version  Description
# ----------- -------- ------------------------------------------------------------------------------
# 2026/11/25  2.0      PowerShell port of cleanup.py v1.1 to remove the Python dependency
# ===================================================================================================

$ErrorActionPreference = 'Stop'

function Fail([string]$msg) {
    [Console]::Error.WriteLine($msg)
    exit 1
}

# ----------------------------------------------------------------------
# Arguments (positional, via $args, to mirror sys.argv)
if ($args.Count -lt 2) {
    Write-Output 'usage: cleanup.py <days> <path> <dryrun>'
    exit 0
}

# int(sys.argv[1]): whole numbers only, surrounding spaces and a leading +/- allowed
$daysText = [string]$args[0]
[long]$days = 0
if (-not [long]::TryParse($daysText.Trim(),
        [System.Globalization.NumberStyles]::AllowLeadingSign,
        [System.Globalization.CultureInfo]::InvariantCulture, [ref]$days)) {
    Fail ("ValueError: invalid literal for int() with base 10: '" + $daysText + "'")
}

$jobsPath = [string]$args[1]

$dryrun = ($args.Count -gt 2)

# ----------------------------------------------------------------------
# os.path.join(path, name): only add a separator if path does not already end in one (or is "e:")
function Join-JobPath([string]$parent, [string]$name) {
    if ($parent.Length -eq 0 -or $parent.EndsWith('\') -or $parent.EndsWith('/') -or
        ($parent.Length -eq 2 -and $parent[1] -eq ':')) {
        return $parent + $name
    }
    return $parent + '\' + $name
}

# ----------------------------------------------------------------------
function Remove-JobFolder([string]$fullPath) {
    Write-Output ('Deleting: ' + $fullPath)
    if ($dryrun) { return }
    try {
        $item = New-Object System.IO.DirectoryInfo $fullPath
        if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
            # Python 3.12 shutil.rmtree refuses junctions/symlinks; do the same rather than
            # risk deleting the contents of whatever the link points at.
            throw (New-Object System.IO.IOException ('Cannot call rmtree on a symbolic link: ' + $fullPath))
        }
        # Recursive delete. Like shutil.rmtree, it fails on read-only files and does not follow
        # junctions inside the tree (it removes the link, not the target's contents).
        [System.IO.Directory]::Delete($fullPath, $true)
    }
    catch {
        $e = $_.Exception
        while ($e.InnerException) { $e = $e.InnerException }
        Write-Output ('OS error: ' + $e.Message)
    }
}

# ----------------------------------------------------------------------
# cutoff = now - days*86400 s, compared in UTC so DST changes cannot shift it
$nowUtc = [DateTime]::UtcNow
try {
    $cutoffUtc = $nowUtc.AddDays(-[double]$days)
}
catch {
    if ($days -gt 0) { $cutoffUtc = [DateTime]::MinValue } else { $cutoffUtc = [DateTime]::MaxValue }
}

# Build list of job folders with mtime <= cutoff (os.listdir order, directories only, hidden included)
$jobIds = New-Object System.Collections.Generic.List[string]
try {
    foreach ($dir in [System.IO.Directory]::GetDirectories($jobsPath)) {
        $name = [System.IO.Path]::GetFileName($dir)
        $info = New-Object System.IO.DirectoryInfo $dir
        $mtime = $info.LastWriteTimeUtc
        if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
            # os.stat follows links: use the target's modified time, as Python did
            try {
                $target = (Get-Item -LiteralPath $dir -Force).Target
                if ($target) {
                    $t = @($target)[0]
                    if (-not [System.IO.Path]::IsPathRooted($t)) { $t = Join-Path $jobsPath $t }
                    $mtime = (New-Object System.IO.DirectoryInfo $t).LastWriteTimeUtc
                }
            } catch { }
        }
        if ($mtime -le $cutoffUtc) {
            $jobIds.Add($name)
        }
    }
}
catch {
    $e = $_.Exception
    while ($e.InnerException) { $e = $e.InnerException }
    Fail ('Error reading jobs directory ''' + $jobsPath + ''': ' + $e.Message)
}

# ANSI code page with no BOM (what Python's open(..., "w") used), set to THROW on any character the
# code page can't hold, as Python did (UnicodeEncodeError), instead of silently writing '?'.
$ansi = [System.Text.Encoding]::GetEncoding([System.Text.Encoding]::Default.CodePage,
    [System.Text.EncoderFallback]::ExceptionFallback, [System.Text.DecoderFallback]::ExceptionFallback)

# Python text mode on Windows writes every \n as \r\n
$nl = "`r`n"

if ($jobIds.Count -gt 0) {
    foreach ($job in $jobIds) {
        Remove-JobFolder (Join-JobPath $jobsPath $job)
    }

    # JOB_CLEANUP.xml for CC to delete jobs from db.
    # Byte-for-byte as cleanup.py: single-quoted declaration, tabs, the stray space line after
    # <list>, jobs listed even if their delete failed, no newline at end of file.
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append("<?xml version='1.0'?>" + $nl)
    [void]$sb.Append('<action xmlns="http://www.hp.com/go/exstream/schema/cc-actions">' + $nl)
    [void]$sb.Append("`t<type>JOB_CLEANUP</type>" + $nl)
    [void]$sb.Append("`t<attribute name=`"job_list`">" + $nl)
    [void]$sb.Append("`t`t<list>" + $nl + ' ')
    foreach ($job in $jobIds) {
        [void]$sb.Append("`t`t`t<value>" + $job + '</value>' + $nl)
    }
    [void]$sb.Append("`t`t</list>" + $nl + "`t</attribute>" + $nl + '</action>')
    $xmlContent = $sb.ToString()
}
else {
    Write-Output 'Nothing to clean up.'
    $xmlContent = "<?xml version='1.0'?>" + $nl + '<action>' + $nl + "`t<type>EMPTY</type>" + $nl + '</action>'
}

# Write to the current working directory, ANSI code page, no BOM (same as Python's open(..., "w")).
# Do NOT use Out-File / Set-Content / > here: in 5.1 they write UTF-16 or add a BOM.
try {
    $outFile = Join-Path (Get-Location).ProviderPath 'JOB_CLEANUP.xml'
    # Like Python: open(..., "w") creates/empties the file first; if the content then can't be
    # encoded, the run fails (exit 1) leaving an EMPTY JOB_CLEANUP.xml, after the deletions.
    [System.IO.File]::WriteAllBytes($outFile, (New-Object byte[] 0))
    $bytes = $ansi.GetBytes($xmlContent)
    [System.IO.File]::WriteAllBytes($outFile, $bytes)
}
catch {
    $e = $_.Exception
    while ($e.InnerException) { $e = $e.InnerException }
    Fail ('Could not write JOB_CLEANUP.xml: ' + $e.Message)
}
Write-Output 'JOB_CLEANUP.xml has been created.'
exit 0
