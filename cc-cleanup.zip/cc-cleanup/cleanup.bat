SET DAYS=%1
SET JOBPATH=%2

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File e:\command-center-3.2.0\var\tools\cleanup\cleanup.ps1 %DAYS% %JOBPATH%

exit %ERRORLEVEL%



rem old: "C:\Program Files\Python312\python.exe" e:\command-center-3.2.0\var\tools\cleanup\cleanup.py %DAYS% %PATH%
