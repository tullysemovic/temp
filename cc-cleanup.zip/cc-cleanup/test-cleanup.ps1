# test-cleanup.ps1 - side-by-side check of cleanup.ps1 against cleanup.py on a throwaway folder.
# Run on the server BEFORE removing Python, from any folder:
#   powershell -NoProfile -ExecutionPolicy Bypass -File test-cleanup.ps1
# Only touches folders it creates under %TEMP%. Nothing under E:\ is read or changed.

param(
    [string]$PythonExe = 'C:\Program Files\Python312\python.exe',
    [string]$ToolDir   = 'e:\command-center-3.2.0\var\tools\cleanup'
)
$ErrorActionPreference = 'Continue'   # native stderr + 2>&1 must not throw in 5.1
$ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

function New-Sandbox([string]$root) {
    $jobs = Join-Path $root 'jobs'
    New-Item -ItemType Directory -Path $jobs -Force | Out-Null
    $now = Get-Date
    # name, age in days
    $spec = @(@('1001', 400), @('1002', 366), @('1003', 10), @('job_old_b', 1000), @('1004', 0))
    foreach ($s in $spec) {
        $d = New-Item -ItemType Directory -Path (Join-Path $jobs $s[0]) -Force
        Set-Content -Path (Join-Path $d.FullName 'data.txt') -Value 'x'
        $d.LastWriteTime = $now.AddDays(-$s[1])
    }
    # read-only file inside an old job: Python and PowerShell should both report an error and still list it
    $ro = New-Item -ItemType Directory -Path (Join-Path $jobs '1005') -Force
    $f = Join-Path $ro.FullName 'locked.txt'
    Set-Content -Path $f -Value 'x'
    (Get-Item $f).IsReadOnly = $true
    $ro.LastWriteTime = $now.AddDays(-500)
    # a plain file in the jobs folder must be ignored
    Set-Content -Path (Join-Path $jobs 'readme.txt') -Value 'x'
    (Get-Item (Join-Path $jobs 'readme.txt')).LastWriteTime = $now.AddDays(-900)
    return $jobs
}

function Run-Case([string]$label, [string[]]$extra, [int]$days, [switch]$Empty) {
    $base = Join-Path $env:TEMP ('cc-cleanup-test-' + [guid]::NewGuid().ToString('N'))
    $pyJobs = New-Sandbox (Join-Path $base 'py')
    $psJobs = New-Sandbox (Join-Path $base 'ps')
    if ($Empty) {
        Get-ChildItem $pyJobs -Directory | ForEach-Object { $_.LastWriteTime = Get-Date }
        Get-ChildItem $psJobs -Directory | ForEach-Object { $_.LastWriteTime = Get-Date }
    }

    Push-Location (Split-Path $pyJobs)
    $pyOut = & $PythonExe (Join-Path $ToolDir 'cleanup.py') $days ($pyJobs + '\') @extra 2>&1
    $pyCode = $LASTEXITCODE
    Pop-Location

    Push-Location (Split-Path $psJobs)
    $psOut = & $ps -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $ToolDir 'cleanup.ps1') $days ($psJobs + '\') @extra 2>&1
    $psCode = $LASTEXITCODE
    Pop-Location

    $pyXml = [System.IO.File]::ReadAllBytes((Join-Path (Split-Path $pyJobs) 'JOB_CLEANUP.xml'))
    $psXml = [System.IO.File]::ReadAllBytes((Join-Path (Split-Path $psJobs) 'JOB_CLEANUP.xml'))
    $sameXml = ([Convert]::ToBase64String($pyXml) -eq [Convert]::ToBase64String($psXml))

    $pyLeft = (Get-ChildItem $pyJobs -Force | Select-Object -ExpandProperty Name | Sort-Object) -join ','
    $psLeft = (Get-ChildItem $psJobs -Force | Select-Object -ExpandProperty Name | Sort-Object) -join ','

    $ok = $sameXml -and ($pyCode -eq $psCode) -and ($pyLeft -eq $psLeft)
    if ($ok) { $verdict = 'PASS' } else { $verdict = 'FAIL' }
    Write-Host ("[{0}] {1}" -f $verdict, $label)
    Write-Host ("   xml identical: {0} ({1} vs {2} bytes)   exit: py={3} ps={4}" -f $sameXml, $pyXml.Length, $psXml.Length, $pyCode, $psCode)
    Write-Host ("   left behind py: {0}" -f $pyLeft)
    Write-Host ("   left behind ps: {0}" -f $psLeft)
    Write-Host '   --- python output ---';     $pyOut | ForEach-Object { Write-Host ('   ' + $_) }
    Write-Host '   --- powershell output ---'; $psOut | ForEach-Object { Write-Host ('   ' + $_) }

    # tidy up (clear read-only first)
    Get-ChildItem $base -Recurse -Force -File | ForEach-Object { $_.IsReadOnly = $false }
    Remove-Item $base -Recurse -Force
}

Run-Case 'delete jobs older than 365 days' @() 365
Run-Case 'dry run (third argument)' @('dryrun') 365
Run-Case 'nothing to clean (EMPTY xml)' @() 365 -Empty
